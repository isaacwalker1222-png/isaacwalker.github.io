import java.util.NoSuchElementException; 

public class IntSinglyLinkedList {

	 // Class Node with fields. 
	private static class Node {
		int value;
		Node next;
		
		Node (int value) {
		this.value = value;
		this.next = null;
	}

  }
	
	
	
	
	private Node head;
	private int size;
	
	public IntSinglyLinkedList() {
		head = null;
		size = 0;
	}
	// Add Node to the front. 
	public void addFirst (int value) {
	Node newNode = new Node(value);
	newNode.next = head;
	head = newNode;
	size++;
	
	}
	
	
	
	// Adds node to the end. 
	// If the list is empty, a new node becomes the head. 
	// Otherwise it will start at the head and move through the nodes
	// until next is null and it will attach a new node there. 
	public void addLast (int value) {
		Node newNode = new Node(value);
		
		if (head == null) {
			head = newNode;
		} else {
			Node current = head;
			while (current.next != null) {
				current = current.next;
			}
			current.next = newNode;
		}
		size++;
		
		
		
	}
	
	
	// Returns the value at a position. 
	public int get(int index) {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}
		
		Node current = head;
		for (int i=0; i < index; i++) {
			current = current.next;
		}
		return current.value;
			
	}
	
	
	
	
	// Removes the first node.
	public int removeFirst() {
		if (head == null) {
			throw new NoSuchElementException();
		}
		
		int value = head.value;
		head = head.next;
		size--;
		return value;
	}
	
	
	
	public boolean removeValue(int value) {
		if (head == null) return false;
		
		if(head.value == value) {
			head = head.next;
			size --;
			return true;
		}
		
		
		
		Node current = head;
		while (current.next != null) {
			if (current.next.value == value) {
				current.next = current.next.next;
				size--;
				return true;
			}
			current = current.next;
		}
		return false;
	}
	
	
	
	public int size() {
		return size;
	}
	
	public boolean isEmpty() {
		return size == 0;
		
	}
	
	public String toString() {
		String result = "{";
		Node current = head;
		
		while (current != null) {
			result += current.value;
			if (current.next != null) {
				result += ",";
			}
			current = current.next;
		}
		result += "]";
		return result;
	}
	
	
	
	public static void main(String[] args) {
		IntSinglyLinkedList list =  new IntSinglyLinkedList();
		
		System.out.println("List empty? " + list.isEmpty());
		list.addFirst(10);
		list.addFirst(5);
		list.addLast(20);
		list.addLast(30);
		
		System.out.println("List after adds: " + list);
		System.out.println("Size: " + list.size());
		System.out.println("Element at index 2: " +list.get(2));
		
		int removed = list.removeFirst();
		System.out.println("Removed first: " + removed);
		System.out.println("List now: " + list);
		
		
		boolean removedValue = list.removeValue(20);
		System.out.println("Removed value 20? " + removedValue);
		System.out.println("Final list: " + list);
		System.out.println("Final size: " +list.size());
		
	}
	
	
	
	
}
	
	

	

	









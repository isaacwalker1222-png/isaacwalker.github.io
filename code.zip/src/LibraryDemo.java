
public class LibraryDemo {

	public static void main(String[] args) {

        Library lib = new Library();

        Book b1 = new Book("111", "The Hobbit", "J.R.R. Tolkien");
        Book b2 = new Book("222", "1984", "George Orwell");
        Book b3 = new Book("333", "Dune", "Frank Herbert");

        lib.addBook(b1);
        lib.addBook(b2);
        lib.addBook(b3);

        Borrower alice = new Borrower("B1", "Alice");
        Borrower bob = new Borrower("B2", "Bob");

        lib.registerBorrower(alice);
        lib.registerBorrower(bob);

        System.out.println("Checkout The Hobbit to Alice: " + lib.checkout("B1", "111"));
        System.out.println("Is The Hobbit available? " + lib.isAvailable("111"));

        System.out.println("Alice's books: " + lib.getBorrowerBooks("B1"));

        System.out.println("Checking in The Hobbit...");
        lib.checkin("111");

        System.out.println("Is The Hobbit available now? " + lib.isAvailable("111"));
        System.out.println("Alice's books after return: " + lib.getBorrowerBooks("B1"));
    }
}

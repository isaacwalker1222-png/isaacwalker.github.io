import java.util.Objects;

/**
 * Represents a library user who can borrow books and each borrower is uniquely identified by their ID.
 */
public class Borrower {
    private String id;
    private String name;

    public Borrower(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() { return id; }
    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    /**
     * Borrowers are equal if their IDs match.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Borrower)) return false;
        Borrower that = (Borrower) o;
        return id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}

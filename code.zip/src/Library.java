import java.util.*;

public class Library {

    // Keeps books in the order they were added.
    // ArrayList organizes storage.
    private ArrayList<Book> catalog = new ArrayList<>();

    // Maps ISBN to Book for very fast lookup (O(1) average).
    // HashMap is ideal when we frequently search by a unique key.
    private HashMap<String, Book> isbnMap = new HashMap<>();

    // Tracks which books are currently available in the library.
    // HashSet allows fast add/remove/contains and prevents duplicates.
    private HashSet<Book> availableBooks = new HashSet<>();

    // Maps each borrower to the list of books they have checked out.
    // HashMap gives fast borrower lookup, LinkedList is good for a simple history.
    private HashMap<Borrower, LinkedList<Book>> borrowerBooks = new HashMap<>();

    public void addBook(Book book) {
        if (isbnMap.containsKey(book.getIsbn())) {
            return; // no duplicates
        }
        catalog.add(book);
        isbnMap.put(book.getIsbn(), book);
        availableBooks.add(book);
    }

    public Book findByIsbn(String isbn) {
        return isbnMap.get(isbn);
    }

    public boolean isAvailable(String isbn) {
        Book b = isbnMap.get(isbn);
        return b != null && availableBooks.contains(b);
    }

    public void registerBorrower(Borrower b) {
        borrowerBooks.putIfAbsent(b, new LinkedList<>());
    }

    private Borrower findBorrowerById(String id) {
        for (Borrower b : borrowerBooks.keySet()) {
            if (b.getId().equals(id)) {
                return b;
            }
        }
        return null;
    }

    public boolean checkout(String borrowerId, String isbn) {
        Borrower borrower = findBorrowerById(borrowerId);
        if (borrower == null) {
            throw new IllegalArgumentException("Unknown borrower ID.");
        }

        Book book = isbnMap.get(isbn);
        if (book == null) {
            throw new IllegalArgumentException("Unknown ISBN.");
        }

        if (!availableBooks.contains(book)) {
            return false; // not available
        }

        availableBooks.remove(book);
        borrowerBooks.get(borrower).add(book);
        return true;
    }

    public boolean checkin(String isbn) {
        Book book = isbnMap.get(isbn);
        if (book == null) {
            throw new IllegalArgumentException("Unknown ISBN.");
        }

        for (LinkedList<Book> list : borrowerBooks.values()) {
            if (list.remove(book)) {
                availableBooks.add(book);
                return true;
            }
        }
        return false;
    }

    public LinkedList<Book> getBorrowerBooks(String borrowerId) {
        Borrower borrower = findBorrowerById(borrowerId);
        if (borrower == null) return new LinkedList<>();
        return new LinkedList<>(borrowerBooks.get(borrower)); // return copy
    }
}

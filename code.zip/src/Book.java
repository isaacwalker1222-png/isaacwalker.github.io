import java.util.Objects;

/**
 * Represents a single book in the library. Each book is uniquely identified by its ISBN.
 */
public class Book {
    private String isbn;
    private String title;
    private String author;

    /**
     * Creates a Book with an ISBN, title, and author.
     * Throws IllegalArgumentException if any value is null or blank.
     */
    public Book(String isbn, String title, String author) {
        if (isBlank(isbn) || isBlank(title) || isBlank(author)) {
            throw new IllegalArgumentException("Book fields cannot be null or blank");
        }
        this.isbn = isbn;
        this.title = title;
        this.author = author;
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    public String getIsbn() { return isbn; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }

    @Override
    public String toString() {
        return title + " by " + author + " (ISBN: " + isbn + ")";
    }

    /**
     * Books are considered equal if they have the same ISBN.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Book)) return false;
        Book book = (Book) o;
        return isbn.equals(book.isbn);
    }

    @Override
    public int hashCode() {
        return Objects.hash(isbn);
    }
}


